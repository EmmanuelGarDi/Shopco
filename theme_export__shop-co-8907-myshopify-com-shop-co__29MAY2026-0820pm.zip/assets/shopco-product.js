(function () {
  function initProductTabs() {
    document.querySelectorAll('[data-shopco-pdp-tabs]').forEach(function (root) {
      if (root.dataset.shopcoTabsInit) return;
      root.dataset.shopcoTabsInit = 'true';

      var buttons = root.querySelectorAll('[data-shopco-tab]');
      var panels = root.querySelectorAll('[data-shopco-panel]');

      buttons.forEach(function (button) {
        button.addEventListener('click', function () {
          var target = button.getAttribute('data-shopco-tab');

          buttons.forEach(function (btn) {
            btn.classList.toggle('is-active', btn === button);
            btn.setAttribute('aria-selected', btn === button ? 'true' : 'false');
          });

          panels.forEach(function (panel) {
            var isActive = panel.getAttribute('data-shopco-panel') === target;
            panel.classList.toggle('is-active', isActive);
            panel.hidden = !isActive;
          });
        });
      });
    });
  }

  function initProductFaqs() {
    document.querySelectorAll('[data-shopco-faq]').forEach(function (item) {
      var trigger = item.querySelector('[data-shopco-faq-trigger]');
      if (!trigger || item.dataset.shopcoFaqInit) return;
      item.dataset.shopcoFaqInit = 'true';

      trigger.addEventListener('click', function () {
        var isOpen = item.classList.toggle('is-open');
        trigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
    });
  }

  function initLoadMoreReviews() {
    document.querySelectorAll('[data-shopco-load-reviews]').forEach(function (button) {
      if (button.dataset.shopcoLoadInit) return;
      button.dataset.shopcoLoadInit = 'true';

      button.addEventListener('click', function () {
        var grid = button.closest('.shopco-pdp-tabs__panel')?.querySelector('[data-shopco-reviews-grid]');
        if (!grid) return;

        grid.querySelectorAll('[data-shopco-review-hidden]').forEach(function (card) {
          card.removeAttribute('data-shopco-review-hidden');
          card.hidden = false;
        });

        button.hidden = true;
      });
    });
  }

  function init() {
    initProductTabs();
    initProductFaqs();
    initLoadMoreReviews();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  document.addEventListener('shopify:section:load', init);
})();
