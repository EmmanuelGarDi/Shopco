// /**
//  * Filtros Shop.co: slider de precio, colores estáticos, drawer móvil.
//  */
// (function () {
//   const ROOT_SELECTOR = '.shopco-collection';
//   const OPEN_CLASS = 'shopco-filters-open';

//   function parseMoney(value, fallback) {
//     if (value == null || value === '') return fallback;
//     const cleaned = String(value).replace(/[^\d.,]/g, '').replace(/(\..*)\./g, '$1');
//     const normalized = cleaned.includes(',') && !cleaned.includes('.')
//       ? cleaned.replace(',', '.')
//       : cleaned.replace(/,/g, '');
//     const num = parseFloat(normalized);
//     return Number.isFinite(num) ? num : fallback;
//   }

//   function classifyFilters(root) {
//     root.querySelectorAll('.facets__item').forEach((item) => {
//       const label =
//         item.querySelector('.facets__summary .facets__label, .facets__label')?.textContent?.trim().toLowerCase() ||
//         '';

//       item.classList.remove('shopco-filter--color', 'shopco-filter--size', 'shopco-filter--price', 'shopco-filter--list');

//       if (/color|colour|couleur|farbe|colore/.test(label)) {
//         item.classList.add('shopco-filter--color');
//         item.closest('.shopco-filters-native')?.classList.add('shopco-has-native-color');
//       } else if (/size|talla|taille|größe/.test(label)) {
//         item.classList.add('shopco-filter--size');
//       } else if (/price|precio|preis|prix/.test(label)) {
//         item.classList.add('shopco-filter--price');
//         item.closest('.shopco-filters-native')?.classList.add('shopco-has-native-price');
//       } else {
//         item.classList.add('shopco-filter--list');
//       }
//     });

//     if (root.querySelector('.shopco-has-native-color')) {
//       root.querySelector('.shopco-static-filter--colors')?.remove();
//     }
//     if (root.querySelector('.shopco-has-native-price')) {
//       root.querySelector('.shopco-static-filter--price')?.remove();
//     }
//   }

//   function buildPriceRangeHTML(rangeMin, rangeMax, valueMin, valueMax) {
//     return `
//       <div class="shopco-price-range__slider">
//         <div class="shopco-price-range__track" aria-hidden="true">
//           <div class="shopco-price-range__fill"></div>
//         </div>
//         <input type="range" class="shopco-price-range__input shopco-price-range__input--min"
//           min="${rangeMin}" max="${rangeMax}" value="${valueMin}" step="1" aria-label="Minimum price">
//         <input type="range" class="shopco-price-range__input shopco-price-range__input--max"
//           min="${rangeMin}" max="${rangeMax}" value="${valueMax}" step="1" aria-label="Maximum price">
//       </div>
//       <div class="shopco-price-range__labels">
//         <span class="shopco-price-range__label shopco-price-range__label--min"></span>
//         <span class="shopco-price-range__label shopco-price-range__label--max"></span>
//       </div>
//     `;
//   }

//   function initPriceRangeEl(wrap) {
//     if (wrap.dataset.shopcoPriceInit === 'true') return;
//     wrap.dataset.shopcoPriceInit = 'true';

//     const minInput = wrap.querySelector('.shopco-price-range__input--min');
//     const maxInput = wrap.querySelector('.shopco-price-range__input--max');
//     const fill = wrap.querySelector('.shopco-price-range__fill');
//     const labelMin = wrap.querySelector('.shopco-price-range__label--min');
//     const labelMax = wrap.querySelector('.shopco-price-range__label--max');

//     if (!minInput || !maxInput || !fill) return;

//     const rangeMin = parseMoney(wrap.dataset.rangeMin, 0);
//     let rangeMax = parseMoney(wrap.dataset.rangeMax || maxInput.max, 200);
//     if (rangeMax <= rangeMin) rangeMax = rangeMin + 200;

//     const currency = wrap.dataset.currency || '$';
//     const defaultMin = parseMoney(wrap.dataset.defaultMin, Math.min(50, rangeMax));
//     const defaultMax = parseMoney(wrap.dataset.defaultMax, rangeMax);

//     minInput.min = String(rangeMin);
//     minInput.max = String(rangeMax);
//     maxInput.min = String(rangeMin);
//     maxInput.max = String(rangeMax);

//     if (!minInput.value || parseMoney(minInput.value, -1) < rangeMin) {
//       minInput.value = String(Math.min(defaultMin, rangeMax));
//     }
//     if (!maxInput.value || parseMoney(maxInput.value, -1) > rangeMax) {
//       maxInput.value = String(Math.max(defaultMax, parseMoney(minInput.value, defaultMin)));
//     }

//     function formatLabel(val) {
//       return currency + Math.round(val);
//     }

//     function updateUI() {
//       let minVal = parseMoney(minInput.value, rangeMin);
//       let maxVal = parseMoney(maxInput.value, rangeMax);

//       minVal = Math.max(rangeMin, Math.min(minVal, rangeMax));
//       maxVal = Math.max(rangeMin, Math.min(maxVal, rangeMax));

//       if (minVal > maxVal) {
//         if (document.activeElement === minInput) {
//           maxVal = minVal;
//           maxInput.value = String(maxVal);
//         } else {
//           minVal = maxVal;
//           minInput.value = String(minVal);
//         }
//       }

//       minInput.value = String(minVal);
//       maxInput.value = String(maxVal);

//       const span = rangeMax - rangeMin || 1;
//       const leftPct = ((minVal - rangeMin) / span) * 100;
//       const rightPct = ((maxVal - rangeMin) / span) * 100;

//       fill.style.left = leftPct + '%';
//       fill.style.width = Math.max(0, rightPct - leftPct) + '%';

//       if (labelMin) labelMin.textContent = formatLabel(minVal);
//       if (labelMax) labelMax.textContent = formatLabel(maxVal);
//     }

//     minInput.addEventListener('input', updateUI);
//     maxInput.addEventListener('input', updateUI);
//     updateUI();
//   }

//   function initAllPriceRanges(root) {
//     root.querySelectorAll('.shopco-price-range').forEach((wrap) => {
//       if (!wrap.querySelector('.shopco-price-range__slider')) {
//         const rangeMin = parseMoney(wrap.dataset.rangeMin, 0);
//         const rangeMax = parseMoney(wrap.dataset.rangeMax, 200);
//         const valueMin = parseMoney(wrap.dataset.defaultMin, 50);
//         const valueMax = parseMoney(wrap.dataset.defaultMax, rangeMax);
//         wrap.innerHTML = buildPriceRangeHTML(rangeMin, rangeMax, valueMin, valueMax);
//       }
//       initPriceRangeEl(wrap);
//     });

//     root.querySelectorAll('.shopco-filter--price price-facet-component').forEach((facet) => {
//       if (facet.querySelector('.shopco-price-range--converted')) return;

//       const minField = facet.querySelector('input[name*="gte"], input[name*="min"]');
//       const maxField = facet.querySelector('input[name*="lte"], input[name*="max"]');
//       if (!minField || !maxField) return;

//       const rangeMin = 0;
//       let rangeMax = parseMoney(
//         maxField.getAttribute('data-max') || maxField.placeholder || maxField.getAttribute('max'),
//         200
//       );
//       if (rangeMax < 50) rangeMax = 200;

//       let valueMin = parseMoney(minField.value, Math.min(50, rangeMax * 0.25));
//       let valueMax = parseMoney(maxField.value, rangeMax);
//       if (valueMax <= valueMin) valueMax = rangeMax;

//       const wrap = document.createElement('div');
//       wrap.className = 'shopco-price-range shopco-price-range--converted';
//       wrap.dataset.rangeMin = String(rangeMin);
//       wrap.dataset.rangeMax = String(rangeMax);
//       wrap.dataset.defaultMin = String(valueMin);
//       wrap.dataset.defaultMax = String(valueMax);
//       wrap.dataset.currency =
//         minField.closest('.field')?.querySelector('.price-facet__label')?.textContent?.trim() || '$';
//       wrap.innerHTML = buildPriceRangeHTML(rangeMin, rangeMax, valueMin, valueMax);

//       facet.querySelector('.price-facet__inputs-wrapper')?.classList.add('shopco-price-range__inputs--hidden');
//       facet.querySelector('.price-facet__highest-price')?.classList.add('shopco-visually-hidden');

//       const panel =
//         facet.querySelector('.facets__panel-content') || facet.querySelector('.facets__inputs-wrapper') || facet;
//       panel.insertBefore(wrap, panel.firstChild);

//       const minR = wrap.querySelector('.shopco-price-range__input--min');
//       const maxR = wrap.querySelector('.shopco-price-range__input--max');

//       minR.addEventListener('input', () => {
//         minField.value = minR.value;
//         minField.dispatchEvent(new Event('input', { bubbles: true }));
//       });
//       maxR.addEventListener('input', () => {
//         maxField.value = maxR.value;
//         maxField.dispatchEvent(new Event('input', { bubbles: true }));
//       });

//       initPriceRangeEl(wrap);
//     });
//   }

//   function initColorSwatches(root) {
//     root.querySelectorAll('.shopco-color-swatches').forEach((list) => {
//       if (list.dataset.shopcoColorsInit === 'true') return;
//       list.dataset.shopcoColorsInit = 'true';

//       list.addEventListener('click', (e) => {
//         const btn = e.target.closest('.shopco-color-swatch');
//         if (!btn) return;
//         list.querySelectorAll('.shopco-color-swatch').forEach((b) => {
//           b.classList.remove('shopco-color-swatch--active');
//           b.setAttribute('aria-pressed', 'false');
//         });
//         btn.classList.add('shopco-color-swatch--active');
//         btn.setAttribute('aria-pressed', 'true');
//       });
//     });
//   }

//   function initMobileDrawer(root) {
//     if (root.dataset.shopcoDrawerInit === 'true') return;
//     root.dataset.shopcoDrawerInit = 'true';

//     const openBtn = root.querySelector('[data-shopco-open-filters]');
//     const closeButtons = root.querySelectorAll('.shopco-filters-shell__close, .shopco-filters-backdrop');

//     function open() {
//       root.classList.add(OPEN_CLASS);
//       document.body.classList.add('shopco-filters-body-lock');
//       openBtn?.setAttribute('aria-expanded', 'true');
//       root.querySelector('.shopco-filters-shell__close')?.focus();
//     }

//     function handleClose(e) {
//       if (e) {
//         e.preventDefault();
//         e.stopPropagation();
//       }
//       root.classList.remove(OPEN_CLASS);
//       document.body.classList.remove('shopco-filters-body-lock');
//       document.body.style.overflow = '';
//       openBtn?.setAttribute('aria-expanded', 'false');
//     }

//     openBtn?.addEventListener('click', (e) => {
//       e.preventDefault();
//       open();
//     });

//     closeButtons.forEach((btn) => {
//       btn.addEventListener('click', handleClose);
//     });

//     document.addEventListener('keydown', (e) => {
//       if (e.key === 'Escape' && root.classList.contains(OPEN_CLASS)) handleClose(e);
//     });

//     root.querySelector('[data-shopco-apply-filters]')?.addEventListener('click', () => {
//       if (window.innerWidth < 990) handleClose();
//     });
//   }

//   function init(root) {
//     classifyFilters(root);
//     initAllPriceRanges(root);
//     initColorSwatches(root);
//     initMobileDrawer(root);
//   }

//   function boot() {
//     const root = document.querySelector(ROOT_SELECTOR);
//     if (!root) return;
//     init(root);

//     let debounce;
//     const observer = new MutationObserver(() => {
//       clearTimeout(debounce);
//       debounce = setTimeout(() => {
//         classifyFilters(root);
//         initAllPriceRanges(root);
//         initColorSwatches(root);
//       }, 80);
//     });
//     observer.observe(root, { childList: true, subtree: true });
//   }

//   if (document.readyState === 'loading') {
//     document.addEventListener('DOMContentLoaded', boot);
//   } else {
//     boot();
//   }
// })();





/**
 * Filtros Shop.co: slider de precio, colores estáticos, drawer móvil.
 */
(function () {
  const ROOT_SELECTOR = '.shopco-collection';
  const OPEN_CLASS = 'shopco-filters-open';

  function parseMoney(value, fallback) {
    if (value == null || value === '') return fallback;
    const cleaned = String(value).replace(/[^\d.,]/g, '').replace(/(\..*)\./g, '$1');
    const normalized = cleaned.includes(',') && !cleaned.includes('.')
      ? cleaned.replace(',', '.')
      : cleaned.replace(/,/g, '');
    const num = parseFloat(normalized);
    return Number.isFinite(num) ? num : fallback;
  }

  function classifyFilters(root) {
    root.querySelectorAll('.facets__item').forEach((item) => {
      const label =
        item.querySelector('.facets__summary .facets__label, .facets__label')?.textContent?.trim().toLowerCase() ||
        '';

      item.classList.remove('shopco-filter--color', 'shopco-filter--size', 'shopco-filter--price', 'shopco-filter--list');

      if (/color|colour|couleur|farbe|colore/.test(label)) {
        item.classList.add('shopco-filter--color');
        item.closest('.shopco-filters-native')?.classList.add('shopco-has-native-color');
      } else if (/size|talla|taille|größe/.test(label)) {
        item.classList.add('shopco-filter--size');
      } else if (/price|precio|preis|prix/.test(label)) {
        item.classList.add('shopco-filter--price');
        item.closest('.shopco-filters-native')?.classList.add('shopco-has-native-price');
      } else {
        item.classList.add('shopco-filter--list');
      }
    });

    if (root.querySelector('.shopco-has-native-color')) {
      root.classList.add('shopco-has-native-color');
    } else {
      root.classList.remove('shopco-has-native-color');
    }

    if (root.querySelector('.shopco-has-native-price')) {
      root.querySelector('.shopco-static-filter--price')?.remove();
    }
  }

  function buildPriceRangeHTML(rangeMin, rangeMax, valueMin, valueMax) {
    return `
      <div class="shopco-price-range__slider">
        <div class="shopco-price-range__track" aria-hidden="true">
          <div class="shopco-price-range__fill"></div>
        </div>
        <input type="range" class="shopco-price-range__input shopco-price-range__input--min"
          min="${rangeMin}" max="${rangeMax}" value="${valueMin}" step="1" aria-label="Minimum price">
        <input type="range" class="shopco-price-range__input shopco-price-range__input--max"
          min="${rangeMin}" max="${rangeMax}" value="${valueMax}" step="1" aria-label="Maximum price">
      </div>
      <div class="shopco-price-range__labels">
        <span class="shopco-price-range__label shopco-price-range__label--min"></span>
        <span class="shopco-price-range__label shopco-price-range__label--max"></span>
      </div>
    `;
  }

  function initPriceRangeEl(wrap) {
    if (wrap.dataset.shopcoPriceInit === 'true') return;
    wrap.dataset.shopcoPriceInit = 'true';

    const minInput = wrap.querySelector('.shopco-price-range__input--min');
    const maxInput = wrap.querySelector('.shopco-price-range__input--max');
    const fill = wrap.querySelector('.shopco-price-range__fill');
    const labelMin = wrap.querySelector('.shopco-price-range__label--min');
    const labelMax = wrap.querySelector('.shopco-price-range__label--max');

    if (!minInput || !maxInput || !fill) return;

    const rangeMin = parseMoney(wrap.dataset.rangeMin, 0);
    let rangeMax = parseMoney(wrap.dataset.rangeMax || maxInput.max, 200);
    if (rangeMax <= rangeMin) rangeMax = rangeMin + 200;

    const currency = wrap.dataset.currency || '$';
    const defaultMin = parseMoney(wrap.dataset.defaultMin, Math.min(50, rangeMax));
    const defaultMax = parseMoney(wrap.dataset.defaultMax, rangeMax);

    minInput.min = String(rangeMin);
    minInput.max = String(rangeMax);
    maxInput.min = String(rangeMin);
    maxInput.max = String(rangeMax);

    if (!minInput.value || parseMoney(minInput.value, -1) < rangeMin) {
      minInput.value = String(Math.min(defaultMin, rangeMax));
    }
    if (!maxInput.value || parseMoney(maxInput.value, -1) > rangeMax) {
      maxInput.value = String(Math.max(defaultMax, parseMoney(minInput.value, defaultMin)));
    }

    function formatLabel(val) {
      return currency + Math.round(val);
    }

    function updateUI() {
      let minVal = parseMoney(minInput.value, rangeMin);
      let maxVal = parseMoney(maxInput.value, rangeMax);

      minVal = Math.max(rangeMin, Math.min(minVal, rangeMax));
      maxVal = Math.max(rangeMin, Math.min(maxVal, rangeMax));

      if (minVal > maxVal) {
        if (document.activeElement === minInput) {
          maxVal = minVal;
          maxInput.value = String(maxVal);
        } else {
          minVal = maxVal;
          minInput.value = String(minVal);
        }
      }

      minInput.value = String(minVal);
      maxInput.value = String(maxVal);

      const span = rangeMax - rangeMin || 1;
      const leftPct = ((minVal - rangeMin) / span) * 100;
      const rightPct = ((maxVal - rangeMin) / span) * 100;

      fill.style.left = leftPct + '%';
      fill.style.width = Math.max(0, rightPct - leftPct) + '%';

      if (labelMin) labelMin.textContent = formatLabel(minVal);
      if (labelMax) labelMax.textContent = formatLabel(maxVal);
    }

    minInput.addEventListener('input', updateUI);
    maxInput.addEventListener('input', updateUI);
    updateUI();
  }

  function initAllPriceRanges(root) {
    root.querySelectorAll('.shopco-price-range').forEach((wrap) => {
      if (!wrap.querySelector('.shopco-price-range__slider')) {
        const rangeMin = parseMoney(wrap.dataset.rangeMin, 0);
        const rangeMax = parseMoney(wrap.dataset.rangeMax, 200);
        const valueMin = parseMoney(wrap.dataset.defaultMin, 50);
        const valueMax = parseMoney(wrap.dataset.defaultMax, rangeMax);
        wrap.innerHTML = buildPriceRangeHTML(rangeMin, rangeMax, valueMin, valueMax);
      }
      initPriceRangeEl(wrap);
    });

    root.querySelectorAll('.shopco-filter--price price-facet-component').forEach((facet) => {
      if (facet.querySelector('.shopco-price-range--converted')) return;

      const minField = facet.querySelector('input[name*="gte"], input[name*="min"]');
      const maxField = facet.querySelector('input[name*="lte"], input[name*="max"]');
      if (!minField || !maxField) return;

      const rangeMin = 0;
      let rangeMax = parseMoney(
        maxField.getAttribute('data-max') || maxField.placeholder || maxField.getAttribute('max'),
        200
      );
      if (rangeMax < 50) rangeMax = 200;

      let valueMin = parseMoney(minField.value, Math.min(50, rangeMax * 0.25));
      let valueMax = parseMoney(maxField.value, rangeMax);
      if (valueMax <= valueMin) valueMax = rangeMax;

      const wrap = document.createElement('div');
      wrap.className = 'shopco-price-range shopco-price-range--converted';
      wrap.dataset.rangeMin = String(rangeMin);
      wrap.dataset.rangeMax = String(rangeMax);
      wrap.dataset.defaultMin = String(valueMin);
      wrap.dataset.defaultMax = String(valueMax);
      wrap.dataset.currency =
        minField.closest('.field')?.querySelector('.price-facet__label')?.textContent?.trim() || '$';
      wrap.innerHTML = buildPriceRangeHTML(rangeMin, rangeMax, valueMin, valueMax);

      facet.querySelector('.price-facet__inputs-wrapper')?.classList.add('shopco-price-range__inputs--hidden');
      facet.querySelector('.price-facet__highest-price')?.classList.add('shopco-visually-hidden');

      const panel =
        facet.querySelector('.facets__panel-content') || facet.querySelector('.facets__inputs-wrapper') || facet;
      panel.insertBefore(wrap, panel.firstChild);

      const minR = wrap.querySelector('.shopco-price-range__input--min');
      const maxR = wrap.querySelector('.shopco-price-range__input--max');

      minR.addEventListener('input', () => {
        minField.value = minR.value;
        minField.dispatchEvent(new Event('input', { bubbles: true }));
      });
      maxR.addEventListener('input', () => {
        maxField.value = maxR.value;
        maxField.dispatchEvent(new Event('input', { bubbles: true }));
      });

      initPriceRangeEl(wrap);
    });
  }

  function initColorSwatches(root) {
    root.querySelectorAll('.shopco-color-swatches').forEach((list) => {
      if (list.dataset.shopcoColorsInit === 'true') return;
      list.dataset.shopcoColorsInit = 'true';

      list.addEventListener('click', (e) => {
        const btn = e.target.closest('.shopco-color-swatch');
        if (!btn) return;
        list.querySelectorAll('.shopco-color-swatch').forEach((b) => {
          b.classList.remove('shopco-color-swatch--active');
          b.setAttribute('aria-pressed', 'false');
        });
        btn.classList.add('shopco-color-swatch--active');
        btn.setAttribute('aria-pressed', 'true');
      });
    });
  }

  function initMobileDrawer(root) {
    if (root.dataset.shopcoDrawerInit === 'true') return;
    root.dataset.shopcoDrawerInit = 'true';

    const openBtn = root.querySelector('[data-shopco-open-filters]');
    const closeButtons = root.querySelectorAll('.shopco-filters-shell__close, .shopco-filters-backdrop');

    function open() {
      root.classList.add(OPEN_CLASS);
      document.body.classList.add('shopco-filters-body-lock');
      openBtn?.setAttribute('aria-expanded', 'true');
      root.querySelector('.shopco-filters-shell__close')?.focus();
    }

    function handleClose(e) {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      root.classList.remove(OPEN_CLASS);
      document.body.classList.remove('shopco-filters-body-lock');
      document.body.style.overflow = '';
      openBtn?.setAttribute('aria-expanded', 'false');
    }

    openBtn?.addEventListener('click', (e) => {
      e.preventDefault();
      open();
    });

    closeButtons.forEach((btn) => {
      btn.addEventListener('click', handleClose);
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && root.classList.contains(OPEN_CLASS)) handleClose(e);
    });

    root.querySelector('[data-shopco-apply-filters]')?.addEventListener('click', () => {
      if (window.innerWidth < 990) handleClose();
    });
  }

  function init(root) {
    classifyFilters(root);
    initAllPriceRanges(root);
    initColorSwatches(root);
    initMobileDrawer(root);
  }

  function boot() {
    const root = document.querySelector(ROOT_SELECTOR);
    if (!root) return;
    init(root);

    let debounce;
    const observer = new MutationObserver(() => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        classifyFilters(root);
        initAllPriceRanges(root);
        initColorSwatches(root);
      }, 80);
    });
    observer.observe(root, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
