/**
 * SHOP.CO Header — fuerza layout desktop en pantallas >= 750px.
 * El tema usa data-menu-style="drawer" en dispositivos táctiles y cuando
 * el menú hace overflow, lo que muestra hamburguesa + logo centrado en desktop.
 */
const DESKTOP_MQ = window.matchMedia('(min-width: 750px)');

const applyShopcoHeaderMode = () => {
  const header = document.querySelector('#header-component');
  if (!header) return;

  if (DESKTOP_MQ.matches) {
    header.dataset.menuStyle = 'menu';

    const overflowMenu = header.querySelector('overflow-list.overflow-menu');
    if (overflowMenu && typeof overflowMenu.showAll === 'function') {
      overflowMenu.showAll();
    }
  }
};

applyShopcoHeaderMode();

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', applyShopcoHeaderMode);
}

window.addEventListener('load', applyShopcoHeaderMode);
window.addEventListener('resize', applyShopcoHeaderMode);
customElements.whenDefined('overflow-list').then(applyShopcoHeaderMode);

/* Re-aplicar si el tema vuelve a poner drawer en desktop */
const header = document.querySelector('#header-component');
if (header) {
  const observer = new MutationObserver(() => {
    if (DESKTOP_MQ.matches && header.dataset.menuStyle === 'drawer') {
      applyShopcoHeaderMode();
    }
  });
  observer.observe(header, { attributes: true, attributeFilter: ['data-menu-style'] });
}
